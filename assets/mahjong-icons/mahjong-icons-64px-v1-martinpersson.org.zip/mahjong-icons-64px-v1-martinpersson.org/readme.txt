This is version 1.0 of a free set of Mahjong-icons made by Martin Persson. You are free to use and modify these icons for any purpose (personal and commercial), under the condition that you provide a link to http://www.martinpersson.org.

Regards,

Martin Persson
Website: http://www.martinpersson.org
Email: contact@martinpersson.org